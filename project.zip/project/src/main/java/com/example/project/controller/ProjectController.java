package com.example.project.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProjectController {
	@GetMapping("/hello")
	public String page()
	{
		return "page1";
	}
	@GetMapping("homepage/{username}")
	public String homepage(@PathVariable("username") String username)
	{
		return "page1" + username;
	}
}
